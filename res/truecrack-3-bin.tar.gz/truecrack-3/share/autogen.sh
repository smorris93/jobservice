aclocal &&
autoconf &&
autoheader &&
automake --add-missing --copy --gnu &&
echo "You are now ready for running ./configure"


#autoheader &&
#automake --add-missing --copy --gnu &&
#aclocal &&
#autoconf &&
#echo "You are now ready for running ./configure"
